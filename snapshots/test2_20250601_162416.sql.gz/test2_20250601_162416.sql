--
-- PostgreSQL database dump
--

-- Dumped from database version 17.5 (Debian 17.5-1.pgdg120+1)
-- Dumped by pg_dump version 17.5 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.provider_models DROP CONSTRAINT provider_models_provider_id_fkey;
ALTER TABLE ONLY public.provider_models DROP CONSTRAINT provider_models_model_id_fkey;
ALTER TABLE ONLY public.model_aliases DROP CONSTRAINT model_aliases_model_id_fkey;
ALTER TABLE ONLY public.llm_responses DROP CONSTRAINT llm_responses_prompt_id_fkey;
ALTER TABLE ONLY public.llm_responses DROP CONSTRAINT llm_responses_document_id_fkey;
ALTER TABLE ONLY public.llm_responses DROP CONSTRAINT llm_responses_connection_id_fkey;
ALTER TABLE ONLY public.llm_models DROP CONSTRAINT llm_models_provider_id_fkey;
ALTER TABLE ONLY public.documents DROP CONSTRAINT documents_folder_id_fkey;
ALTER TABLE ONLY public.documents DROP CONSTRAINT documents_batch_id_fkey;
ALTER TABLE ONLY public.connections DROP CONSTRAINT connections_provider_id_fkey;
ALTER TABLE ONLY public.connections DROP CONSTRAINT connections_model_id_fkey;
ALTER TABLE ONLY public.docs DROP CONSTRAINT uq_docs_file_path;
ALTER TABLE ONLY public.snapshots DROP CONSTRAINT snapshots_pkey;
ALTER TABLE ONLY public.snapshots DROP CONSTRAINT snapshots_file_path_key;
ALTER TABLE ONLY public.provider_models DROP CONSTRAINT provider_models_pkey;
ALTER TABLE ONLY public.prompts DROP CONSTRAINT prompts_prompt_text_key;
ALTER TABLE ONLY public.prompts DROP CONSTRAINT prompts_pkey;
ALTER TABLE ONLY public.models DROP CONSTRAINT models_pkey;
ALTER TABLE ONLY public.models DROP CONSTRAINT models_common_name_key;
ALTER TABLE ONLY public.model_aliases DROP CONSTRAINT model_aliases_pkey;
ALTER TABLE ONLY public.llm_responses DROP CONSTRAINT llm_responses_pkey;
ALTER TABLE ONLY public.llm_providers DROP CONSTRAINT llm_providers_pkey;
ALTER TABLE ONLY public.llm_providers DROP CONSTRAINT llm_providers_name_key;
ALTER TABLE ONLY public.llm_models DROP CONSTRAINT llm_models_pkey;
ALTER TABLE ONLY public.items DROP CONSTRAINT items_pkey;
ALTER TABLE ONLY public.folders DROP CONSTRAINT folders_pkey;
ALTER TABLE ONLY public.folders DROP CONSTRAINT folders_folder_path_key;
ALTER TABLE ONLY public.documents DROP CONSTRAINT documents_pkey;
ALTER TABLE ONLY public.documents DROP CONSTRAINT documents_filepath_key;
ALTER TABLE ONLY public.docs DROP CONSTRAINT docs_pkey;
ALTER TABLE ONLY public.connections DROP CONSTRAINT connections_pkey;
ALTER TABLE ONLY public.connections DROP CONSTRAINT connections_name_key;
ALTER TABLE ONLY public.batches DROP CONSTRAINT batches_pkey;
ALTER TABLE ONLY public.batches DROP CONSTRAINT batches_batch_number_key;
ALTER TABLE ONLY public.batch_archive DROP CONSTRAINT batch_archive_pkey;
ALTER TABLE ONLY public.alembic_version DROP CONSTRAINT alembic_version_pkc;
ALTER TABLE public.snapshots ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.provider_models ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.prompts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.models ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.model_aliases ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.llm_responses ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.llm_providers ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.llm_models ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.items ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.folders ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.documents ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.docs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.connections ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.batches ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.batch_archive ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.snapshots_id_seq;
DROP TABLE public.snapshots;
DROP SEQUENCE public.provider_models_id_seq;
DROP TABLE public.provider_models;
DROP SEQUENCE public.prompts_id_seq;
DROP TABLE public.prompts;
DROP SEQUENCE public.models_id_seq;
DROP TABLE public.models;
DROP SEQUENCE public.model_aliases_id_seq;
DROP TABLE public.model_aliases;
DROP SEQUENCE public.llm_responses_id_seq;
DROP TABLE public.llm_responses;
DROP SEQUENCE public.llm_providers_id_seq;
DROP TABLE public.llm_providers;
DROP SEQUENCE public.llm_models_id_seq;
DROP TABLE public.llm_models;
DROP SEQUENCE public.items_id_seq;
DROP TABLE public.items;
DROP SEQUENCE public.folders_id_seq;
DROP TABLE public.folders;
DROP SEQUENCE public.documents_id_seq;
DROP TABLE public.documents;
DROP SEQUENCE public.docs_id_seq;
DROP TABLE public.docs;
DROP SEQUENCE public.connections_id_seq;
DROP TABLE public.connections;
DROP SEQUENCE public.batches_id_seq;
DROP TABLE public.batches;
DROP SEQUENCE public.batch_archive_id_seq;
DROP TABLE public.batch_archive;
DROP TABLE public.alembic_version;
DROP EXTENSION vector;
--
-- Name: vector; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS vector WITH SCHEMA public;


--
-- Name: EXTENSION vector; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION vector IS 'vector data type and ivfflat and hnsw access methods';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: batch_archive; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.batch_archive (
    id integer NOT NULL,
    original_batch_id integer NOT NULL,
    batch_number integer NOT NULL,
    batch_name text,
    archived_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    archived_by text,
    archive_reason text DEFAULT 'Manual deletion'::text,
    batch_data json NOT NULL,
    documents_data json NOT NULL,
    llm_responses_data json NOT NULL,
    archive_metadata json
);


--
-- Name: batch_archive_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.batch_archive_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: batch_archive_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.batch_archive_id_seq OWNED BY public.batch_archive.id;


--
-- Name: batches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.batches (
    id integer NOT NULL,
    batch_number integer NOT NULL,
    batch_name text,
    description text,
    folder_path text,
    folder_ids jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    status text DEFAULT 'P'::text NOT NULL,
    total_documents integer DEFAULT 0,
    processed_documents integer DEFAULT 0,
    meta_data json DEFAULT '{}'::json,
    config_snapshot json DEFAULT '{}'::json
);


--
-- Name: batches_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.batches_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: batches_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.batches_id_seq OWNED BY public.batches.id;


--
-- Name: connections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.connections (
    id integer NOT NULL,
    name text NOT NULL,
    description text,
    provider_id integer NOT NULL,
    base_url text,
    api_key text,
    port_no integer,
    connection_config jsonb,
    is_active boolean DEFAULT true NOT NULL,
    connection_status text DEFAULT 'unknown'::text NOT NULL,
    last_tested timestamp without time zone,
    last_test_result text,
    supports_model_discovery boolean DEFAULT true NOT NULL,
    available_models text,
    last_model_sync timestamp without time zone,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    model_id integer
);


--
-- Name: connections_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.connections_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: connections_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.connections_id_seq OWNED BY public.connections.id;


--
-- Name: docs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.docs (
    id integer NOT NULL,
    content bytea NOT NULL,
    content_type text,
    doc_type text,
    file_size integer,
    encoding text DEFAULT 'base64'::text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    file_path text NOT NULL
);


--
-- Name: docs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.docs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: docs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.docs_id_seq OWNED BY public.docs.id;


--
-- Name: documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.documents (
    id integer NOT NULL,
    filepath text NOT NULL,
    filename text NOT NULL,
    folder_id integer,
    batch_id integer,
    meta_data jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    task_id text,
    valid text DEFAULT 'Y'::text NOT NULL
);


--
-- Name: documents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.documents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.documents_id_seq OWNED BY public.documents.id;


--
-- Name: folders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.folders (
    id integer NOT NULL,
    folder_path text NOT NULL,
    folder_name text,
    active integer DEFAULT 1,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    status text DEFAULT 'NOT_PROCESSED'::text NOT NULL
);


--
-- Name: folders_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.folders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: folders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.folders_id_seq OWNED BY public.folders.id;


--
-- Name: items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.items (
    id integer NOT NULL,
    embedding public.vector(3)
);


--
-- Name: items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.items_id_seq OWNED BY public.items.id;


--
-- Name: llm_models; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.llm_models (
    id integer NOT NULL,
    provider_id integer,
    model_name text NOT NULL,
    model_id text NOT NULL,
    is_active boolean DEFAULT false NOT NULL,
    capabilities text,
    last_updated timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: llm_models_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.llm_models_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: llm_models_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.llm_models_id_seq OWNED BY public.llm_models.id;


--
-- Name: llm_providers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.llm_providers (
    id integer NOT NULL,
    name text NOT NULL,
    provider_type text NOT NULL,
    default_base_url text,
    supports_model_discovery boolean DEFAULT true NOT NULL,
    auth_type text DEFAULT 'api_key'::text NOT NULL,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: llm_providers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.llm_providers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: llm_providers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.llm_providers_id_seq OWNED BY public.llm_providers.id;


--
-- Name: llm_responses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.llm_responses (
    id integer NOT NULL,
    document_id integer,
    prompt_id integer,
    task_id text,
    status text DEFAULT 'N'::text,
    started_processing_at timestamp without time zone,
    completed_processing_at timestamp without time zone,
    response_json text,
    response_text text,
    response_time_ms integer,
    error_message text,
    overall_score double precision,
    input_tokens integer,
    output_tokens integer,
    time_taken_seconds double precision,
    tokens_per_second double precision,
    "timestamp" timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    connection_id integer NOT NULL,
    connection_details jsonb
);


--
-- Name: llm_responses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.llm_responses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: llm_responses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.llm_responses_id_seq OWNED BY public.llm_responses.id;


--
-- Name: model_aliases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_aliases (
    id integer NOT NULL,
    model_id integer NOT NULL,
    alias_name text NOT NULL,
    provider_pattern text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: model_aliases_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.model_aliases_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: model_aliases_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.model_aliases_id_seq OWNED BY public.model_aliases.id;


--
-- Name: models; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.models (
    id integer NOT NULL,
    common_name text NOT NULL,
    display_name text NOT NULL,
    notes text,
    model_family text,
    parameter_count text,
    context_length integer,
    capabilities text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    is_globally_active boolean DEFAULT true NOT NULL
);


--
-- Name: models_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.models_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: models_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.models_id_seq OWNED BY public.models.id;


--
-- Name: prompts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.prompts (
    id integer NOT NULL,
    prompt_text text NOT NULL,
    description text,
    active integer DEFAULT 1,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: prompts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.prompts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: prompts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.prompts_id_seq OWNED BY public.prompts.id;


--
-- Name: provider_models; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.provider_models (
    id integer NOT NULL,
    provider_id integer NOT NULL,
    model_id integer NOT NULL,
    provider_model_name text NOT NULL,
    is_active boolean DEFAULT false,
    is_available boolean DEFAULT true,
    last_checked timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: provider_models_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.provider_models_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: provider_models_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.provider_models_id_seq OWNED BY public.provider_models.id;


--
-- Name: snapshots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.snapshots (
    id integer NOT NULL,
    name text NOT NULL,
    description text,
    file_path text NOT NULL,
    file_size integer,
    database_name text NOT NULL,
    snapshot_type text NOT NULL,
    compression text NOT NULL,
    created_at timestamp without time zone,
    created_by text,
    tables_included jsonb,
    record_counts jsonb,
    database_version text,
    application_version text,
    status text NOT NULL,
    error_message text,
    notes text,
    tags jsonb
);


--
-- Name: snapshots_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.snapshots_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: snapshots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.snapshots_id_seq OWNED BY public.snapshots.id;


--
-- Name: batch_archive id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_archive ALTER COLUMN id SET DEFAULT nextval('public.batch_archive_id_seq'::regclass);


--
-- Name: batches id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batches ALTER COLUMN id SET DEFAULT nextval('public.batches_id_seq'::regclass);


--
-- Name: connections id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.connections ALTER COLUMN id SET DEFAULT nextval('public.connections_id_seq'::regclass);


--
-- Name: docs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.docs ALTER COLUMN id SET DEFAULT nextval('public.docs_id_seq'::regclass);


--
-- Name: documents id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents ALTER COLUMN id SET DEFAULT nextval('public.documents_id_seq'::regclass);


--
-- Name: folders id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.folders ALTER COLUMN id SET DEFAULT nextval('public.folders_id_seq'::regclass);


--
-- Name: items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items ALTER COLUMN id SET DEFAULT nextval('public.items_id_seq'::regclass);


--
-- Name: llm_models id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.llm_models ALTER COLUMN id SET DEFAULT nextval('public.llm_models_id_seq'::regclass);


--
-- Name: llm_providers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.llm_providers ALTER COLUMN id SET DEFAULT nextval('public.llm_providers_id_seq'::regclass);


--
-- Name: llm_responses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.llm_responses ALTER COLUMN id SET DEFAULT nextval('public.llm_responses_id_seq'::regclass);


--
-- Name: model_aliases id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_aliases ALTER COLUMN id SET DEFAULT nextval('public.model_aliases_id_seq'::regclass);


--
-- Name: models id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.models ALTER COLUMN id SET DEFAULT nextval('public.models_id_seq'::regclass);


--
-- Name: prompts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prompts ALTER COLUMN id SET DEFAULT nextval('public.prompts_id_seq'::regclass);


--
-- Name: provider_models id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.provider_models ALTER COLUMN id SET DEFAULT nextval('public.provider_models_id_seq'::regclass);


--
-- Name: snapshots id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.snapshots ALTER COLUMN id SET DEFAULT nextval('public.snapshots_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alembic_version (version_num) FROM stdin;
fd196deb262e
\.


--
-- Data for Name: batch_archive; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.batch_archive (id, original_batch_id, batch_number, batch_name, archived_at, archived_by, archive_reason, batch_data, documents_data, llm_responses_data, archive_metadata) FROM stdin;
\.


--
-- Data for Name: batches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.batches (id, batch_number, batch_name, description, folder_path, folder_ids, created_at, started_at, completed_at, status, total_documents, processed_documents, meta_data, config_snapshot) FROM stdin;
\.


--
-- Data for Name: connections; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.connections (id, name, description, provider_id, base_url, api_key, port_no, connection_config, is_active, connection_status, last_tested, last_test_result, supports_model_discovery, available_models, last_model_sync, notes, created_at, updated_at, model_id) FROM stdin;
1	My Local Ollama Connection	Connection to local Ollama server for Gemma 3 27B model	1	http://studio.local	\N	11434	{}	t	connected	2025-05-31 19:17:30.565181	Connection successful	t	\N	\N		2025-05-31 19:00:24.214422	2025-05-31 22:22:26.362644	8
2	test_connection_1748744478	\N	1	http://test.local		11434	\N	t	unknown	\N	\N	t	\N	\N	\N	2025-06-01 02:21:18.085718	2025-06-01 02:21:18.085718	\N
3	test_connection_1748744540	\N	1	http://test.local		11434	\N	t	unknown	\N	\N	t	\N	\N	\N	2025-06-01 02:22:20.509676	2025-06-01 02:22:20.509676	\N
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.documents (id, filepath, filename, folder_id, batch_id, meta_data, created_at, task_id, valid) FROM stdin;
\.


--
-- Data for Name: folders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.folders (id, folder_path, folder_name, active, created_at, status) FROM stdin;
3	/Users/frankfilippis/AI/CAPUS/04 - MODULA DOCUMENTATION/F500	F500	1	2025-05-31 18:05:56.991782	READY
5	/Users/frankfilippis/AI/CAPUS/04 - MODULA DOCUMENTATION/08 VLMs	08 VLMs	1	2025-06-01 04:07:09.523377	READY
6	/Users/frankfilippis/AI/CAPUS/04 - MODULA DOCUMENTATION	CAPUS	1	2025-06-01 04:41:20.825751	READY
\.


--
-- Data for Name: items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.items (id, embedding) FROM stdin;
\.


--
-- Data for Name: llm_models; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.llm_models (id, provider_id, model_name, model_id, is_active, capabilities, last_updated) FROM stdin;
\.


--
-- Data for Name: llm_providers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.llm_providers (id, name, provider_type, default_base_url, supports_model_discovery, auth_type, notes, created_at, is_active) FROM stdin;
1	Studio Ollama	ollama	http://studio.local:11434	t	none	Studio Olllama	2025-05-31 18:47:12.707134	t
\.


--
-- Data for Name: llm_responses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.llm_responses (id, document_id, prompt_id, task_id, status, started_processing_at, completed_processing_at, response_json, response_text, response_time_ms, error_message, overall_score, input_tokens, output_tokens, time_taken_seconds, tokens_per_second, "timestamp", created_at, connection_id, connection_details) FROM stdin;
\.


--
-- Data for Name: model_aliases; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.model_aliases (id, model_id, alias_name, provider_pattern, created_at) FROM stdin;
1	1	qwen3:235b	\N	2025-05-31 18:53:27.165587
2	2	llama3.3:70b	\N	2025-05-31 18:53:27.17985
3	3	qwen3:30b	\N	2025-05-31 18:53:27.18834
4	4	phi4-reasoning:latest	\N	2025-05-31 18:53:27.195848
5	5	gemma3:27b	\N	2025-05-31 18:53:27.20365
6	6	mistral:latest	\N	2025-05-31 18:53:27.211131
7	7	nomic-embed-text:latest	\N	2025-05-31 18:53:27.219033
8	8	gemma3:latest	\N	2025-05-31 18:53:27.226394
\.


--
-- Data for Name: models; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.models (id, common_name, display_name, notes, model_family, parameter_count, context_length, capabilities, created_at, updated_at, is_globally_active) FROM stdin;
2	llama3.3-70b	llama3.3:70b	\N	LLaMA	70B	\N	\N	2025-05-31 18:53:27.17985	2025-05-31 18:53:27.17985	t
3	qwen3-30b	qwen3:30b	\N	Qwen	30B	\N	\N	2025-05-31 18:53:27.18834	2025-05-31 18:53:27.18834	t
4	phi4-reasoning-latest	phi4-reasoning:latest	\N	Other	\N	\N	\N	2025-05-31 18:53:27.195848	2025-05-31 18:53:27.195848	t
5	gemma3-27b	gemma3:27b	\N	Other	27B	\N	\N	2025-05-31 18:53:27.20365	2025-05-31 18:53:27.20365	t
6	mistral-latest	mistral:latest	\N	Mistral	\N	\N	\N	2025-05-31 18:53:27.211131	2025-05-31 18:53:27.211131	t
7	nomic-embed-text-latest	nomic-embed-text:latest	\N	Other	\N	\N	\N	2025-05-31 18:53:27.219033	2025-05-31 18:53:27.219033	t
8	gemma3-latest	gemma3:latest	\N	Other	\N	\N	\N	2025-05-31 18:53:27.226394	2025-05-31 18:53:27.226394	t
1	qwen3-235b	Qwen 3 - 235B Parameters (Ultra Large)	Ultra-large language model with 235 billion parameters. Excellent for complex reasoning tasks and detailed analysis.	Qwen	235B	\N	\N	2025-05-31 18:53:27.165587	2025-05-31 18:54:05.494717	t
\.


--
-- Data for Name: prompts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.prompts (id, prompt_text, description, active, created_at) FROM stdin;
1	Analyze this document and provide a comprehensive summary including key points, main themes, and important details.	Document Analysis and Summary	1	2025-05-31 16:55:30.769444
2	Extract all important entities from this document including names, dates, locations, organizations, and key concepts.	Entity Extraction	1	2025-05-31 16:55:30.769444
3	Identify the sentiment and tone of this document. Is it positive, negative, or neutral? Explain your reasoning.	Sentiment Analysis	1	2025-05-31 16:55:30.769444
4	Generate 5 relevant questions that this document answers, along with the answers found in the text.	Question Generation	1	2025-05-31 16:55:30.769444
\.


--
-- Data for Name: provider_models; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.provider_models (id, provider_id, model_id, provider_model_name, is_active, is_available, last_checked, created_at) FROM stdin;
1	1	1	qwen3:235b	f	t	2025-05-31 19:07:22.067275	2025-05-31 18:53:27.17237
2	1	2	llama3.3:70b	f	t	2025-05-31 19:07:22.078896	2025-05-31 18:53:27.183734
3	1	3	qwen3:30b	f	t	2025-05-31 19:07:22.091216	2025-05-31 18:53:27.191707
4	1	4	phi4-reasoning:latest	f	t	2025-05-31 19:07:22.102481	2025-05-31 18:53:27.199193
5	1	5	gemma3:27b	f	t	2025-05-31 19:07:22.111805	2025-05-31 18:53:27.207016
6	1	6	mistral:latest	f	t	2025-05-31 19:07:22.117762	2025-05-31 18:53:27.21461
7	1	7	nomic-embed-text:latest	f	t	2025-05-31 19:07:22.121722	2025-05-31 18:53:27.222074
8	1	8	gemma3:latest	f	t	2025-05-31 19:07:22.126902	2025-05-31 18:53:27.229325
\.


--
-- Data for Name: snapshots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.snapshots (id, name, description, file_path, file_size, database_name, snapshot_type, compression, created_at, created_by, tables_included, record_counts, database_version, application_version, status, error_message, notes, tags) FROM stdin;
1	quick_test	Quick snapshot test excluding docs table data	/Users/frankfilippis/AI/Github/DocumentEvaluator/snapshots/quick_test_20250601_154753.sql.gz	103057	doc_eval	quick	gzip	2025-06-01 19:47:51.538032	maintenance_api	["llm_responses", "documents", "docs", "connections", "models", "providers", "batches", "snapshots"]	{"docs": 3087, "models": 8, "batches": 2, "documents": 2187, "providers": 1, "snapshots": 0, "connections": 3, "llm_responses": 0}	PostgreSQL 17.5 (Debian 17.5-1.pgdg120+1) on aarch64-unknown-linux-gnu, compiled by gcc (Debian 12.2.0-14) 12.2.0, 64-bit	1.0.0	completed	\N	\N	\N
\.


--
-- Name: batch_archive_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.batch_archive_id_seq', 1, false);


--
-- Name: batches_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.batches_id_seq', 56, true);


--
-- Name: connections_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.connections_id_seq', 3, true);


--
-- Name: docs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.docs_id_seq', 3892, true);


--
-- Name: documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.documents_id_seq', 2684, true);


--
-- Name: folders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.folders_id_seq', 6, true);


--
-- Name: items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.items_id_seq', 1, false);


--
-- Name: llm_models_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.llm_models_id_seq', 1, false);


--
-- Name: llm_providers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.llm_providers_id_seq', 2, true);


--
-- Name: llm_responses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.llm_responses_id_seq', 1953, true);


--
-- Name: model_aliases_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.model_aliases_id_seq', 8, true);


--
-- Name: models_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.models_id_seq', 8, true);


--
-- Name: prompts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.prompts_id_seq', 4, true);


--
-- Name: provider_models_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.provider_models_id_seq', 8, true);


--
-- Name: snapshots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.snapshots_id_seq', 1, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: batch_archive batch_archive_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batch_archive
    ADD CONSTRAINT batch_archive_pkey PRIMARY KEY (id);


--
-- Name: batches batches_batch_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batches
    ADD CONSTRAINT batches_batch_number_key UNIQUE (batch_number);


--
-- Name: batches batches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.batches
    ADD CONSTRAINT batches_pkey PRIMARY KEY (id);


--
-- Name: connections connections_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.connections
    ADD CONSTRAINT connections_name_key UNIQUE (name);


--
-- Name: connections connections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.connections
    ADD CONSTRAINT connections_pkey PRIMARY KEY (id);


--
-- Name: docs docs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.docs
    ADD CONSTRAINT docs_pkey PRIMARY KEY (id);


--
-- Name: documents documents_filepath_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_filepath_key UNIQUE (filepath);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: folders folders_folder_path_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.folders
    ADD CONSTRAINT folders_folder_path_key UNIQUE (folder_path);


--
-- Name: folders folders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.folders
    ADD CONSTRAINT folders_pkey PRIMARY KEY (id);


--
-- Name: items items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_pkey PRIMARY KEY (id);


--
-- Name: llm_models llm_models_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.llm_models
    ADD CONSTRAINT llm_models_pkey PRIMARY KEY (id);


--
-- Name: llm_providers llm_providers_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.llm_providers
    ADD CONSTRAINT llm_providers_name_key UNIQUE (name);


--
-- Name: llm_providers llm_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.llm_providers
    ADD CONSTRAINT llm_providers_pkey PRIMARY KEY (id);


--
-- Name: llm_responses llm_responses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.llm_responses
    ADD CONSTRAINT llm_responses_pkey PRIMARY KEY (id);


--
-- Name: model_aliases model_aliases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_aliases
    ADD CONSTRAINT model_aliases_pkey PRIMARY KEY (id);


--
-- Name: models models_common_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.models
    ADD CONSTRAINT models_common_name_key UNIQUE (common_name);


--
-- Name: models models_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.models
    ADD CONSTRAINT models_pkey PRIMARY KEY (id);


--
-- Name: prompts prompts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prompts
    ADD CONSTRAINT prompts_pkey PRIMARY KEY (id);


--
-- Name: prompts prompts_prompt_text_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prompts
    ADD CONSTRAINT prompts_prompt_text_key UNIQUE (prompt_text);


--
-- Name: provider_models provider_models_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.provider_models
    ADD CONSTRAINT provider_models_pkey PRIMARY KEY (id);


--
-- Name: snapshots snapshots_file_path_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.snapshots
    ADD CONSTRAINT snapshots_file_path_key UNIQUE (file_path);


--
-- Name: snapshots snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.snapshots
    ADD CONSTRAINT snapshots_pkey PRIMARY KEY (id);


--
-- Name: docs uq_docs_file_path; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.docs
    ADD CONSTRAINT uq_docs_file_path UNIQUE (file_path);


--
-- Name: connections connections_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.connections
    ADD CONSTRAINT connections_model_id_fkey FOREIGN KEY (model_id) REFERENCES public.models(id);


--
-- Name: connections connections_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.connections
    ADD CONSTRAINT connections_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.llm_providers(id);


--
-- Name: documents documents_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_batch_id_fkey FOREIGN KEY (batch_id) REFERENCES public.batches(id);


--
-- Name: documents documents_folder_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_folder_id_fkey FOREIGN KEY (folder_id) REFERENCES public.folders(id);


--
-- Name: llm_models llm_models_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.llm_models
    ADD CONSTRAINT llm_models_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.llm_providers(id);


--
-- Name: llm_responses llm_responses_connection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.llm_responses
    ADD CONSTRAINT llm_responses_connection_id_fkey FOREIGN KEY (connection_id) REFERENCES public.connections(id);


--
-- Name: llm_responses llm_responses_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.llm_responses
    ADD CONSTRAINT llm_responses_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id);


--
-- Name: llm_responses llm_responses_prompt_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.llm_responses
    ADD CONSTRAINT llm_responses_prompt_id_fkey FOREIGN KEY (prompt_id) REFERENCES public.prompts(id);


--
-- Name: model_aliases model_aliases_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_aliases
    ADD CONSTRAINT model_aliases_model_id_fkey FOREIGN KEY (model_id) REFERENCES public.models(id);


--
-- Name: provider_models provider_models_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.provider_models
    ADD CONSTRAINT provider_models_model_id_fkey FOREIGN KEY (model_id) REFERENCES public.models(id);


--
-- Name: provider_models provider_models_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.provider_models
    ADD CONSTRAINT provider_models_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.llm_providers(id);


--
-- PostgreSQL database dump complete
--

